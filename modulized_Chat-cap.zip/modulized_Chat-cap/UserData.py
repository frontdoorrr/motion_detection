username = "NONE"
room_number = "ROOM"
motion_msg = "NONE"
ip_address = '15.164.244.179'
port_num = 8889