username = "NONE"
room_number = "ROOM"
motion_msg = "NONE"
